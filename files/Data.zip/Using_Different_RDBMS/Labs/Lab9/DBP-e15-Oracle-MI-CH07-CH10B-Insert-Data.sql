/********************************************************************************/
/*																				*/
/*	Kroenke, Auer, Vandenberg, and Yoder					*/
/*	Database Processing (15th Edition) Chapter 07/10B			*/
/*																				*/
/*	MI Insert Data							*/
/*																				*/
/*	These are the Oracle Express 11gR2 and 12c Release 2 SQL code solutions			*/
/*	   for	Chapter 07/10B 						*/
/********************************************************************************/


/*****   EMPLOYEE Data   ********************************************************/

INSERT INTO EMPLOYEE VALUES (seqEID.nextVal,
    'Morgan', 'James', 'Executive', 'CEO', NULL, '310-208-1401', '310-208-1499',
    'James.Morgan@morganimporting.com');

INSERT INTO EMPLOYEE VALUES (seqEID.nextVal,
    'Morgan', 'Jessica', 'Executive', 'CFO', 101, '310-208-1402', '310-208-1499',
    'Jessica.Morgan@morganimporting.com');

INSERT INTO EMPLOYEE VALUES (seqEID.nextVal,
    'Williams', 'David', 'Purchasing', 'Purchasing Manager', 101, '310-208-1434', '310-208-1498',
    'David.Williams@morganimporting.com');

INSERT INTO EMPLOYEE VALUES (seqEID.nextVal,
    'Gilbertson', 'Teri', 'Purchasing', 'Purchasing Agent', 103, '310-208-1435', '310-208-1498',
    'Teri.Gilbertson@morganimporting.com');

INSERT INTO EMPLOYEE VALUES (seqEID.nextVal,
    'Wright', 'James', 'Receiving', 'Receiving Supervisor', 101, '310-208-1456', '310-208-1497',
    'James.Wright@morganimporting.com');

INSERT INTO EMPLOYEE VALUES (seqEID.nextVal,
    'Douglas', 'Tom', 'Receiving', 'Receiving Agent', 105, '310-208-1457', '310-208-1497',
    'Tom.Douglas@morganimporting.com');
	

/*****   STORE Data   ***********************************************************/

INSERT INTO STORE VALUES (seqSTOREID.nextVal,
		'Eastern Sales', 'Singapore', 'Singapore', '65-543-1233',
		'65-543-1239', 'Sales@EasternSales.com.sg', 'Jeremy');

INSERT INTO STORE VALUES (seqSTOREID.nextVal,
		'Eastern Treasures', 'Manila', 'Philippines', '63-2-654-2344',
		'63-2-654-2349', 'Sales@EasternTreasures.com.ph', 'Gracielle');

INSERT INTO STORE VALUES (seqSTOREID.nextVal,
		'Jade Antiques', 'Singapore', 'Singapore', '65-543-3455',
		'65-543-3459', 'Sales@JadeAntiques.com.sg', 'Swee Lai');

INSERT INTO STORE VALUES (seqSTOREID.nextVal,
		'Andes Treasures', 'Lima', 'Peru', '51-14-765-4566',
		'51-14-765-4569', 'Sales@AndesTreasures.com.pe', 'Juan Carlos');

INSERT INTO STORE VALUES (seqSTOREID.nextVal,
		'Eastern Sales', 'Hong Kong', 'People''s Republic of China', '852-876-5677',
		'852-876-5679', 'Sales@EasternSales.com.hk', 'Sam');

INSERT INTO STORE VALUES (seqSTOREID.nextVal,
		'Eastern Treasures', 'New Delhi', 'India', '91-11-987-6788',
		'91-11-987-6789', 'Sales@EasternTreasures.com.in', 'Deepinder');

INSERT INTO STORE VALUES (seqSTOREID.nextVal,
		'EuropeanImports', 'New York City', 'United States', '800-432-8766',
		'800-432-8769', 'Sales@EuropeanImports.com', 'Marcello');

/*****   SHIPPER Data   ***********************************************************/

INSERT INTO SHIPPER VALUES (seqSHIPPERID.nextVal,
		'ABC Trans-Oceanic', '800-234-5656', '800-234-5659',
		'Sales@ABCTransOceanic.com', 'Jonathan');
INSERT INTO SHIPPER VALUES (seqSHIPPERID.nextVal,
		'International', '800-123-8898', '800-123-8899',
		'Sales@International.com', 'Marylin');
INSERT INTO SHIPPER VALUES (seqSHIPPERID.nextVal,
		'Worldwide', '800-123-4567', '800-123-4569',
		'Sales@Worldwide.com', 'Jose');

/*****   PURCHASE_ITEM Data   ***********************************************************/

INSERT INTO PURCHASE_ITEM VALUES (seqIID.nextVal,
		1050, 101, '10-Dec-17', 'Antique Large Bureaus', 'Furniture', 13415);

INSERT INTO PURCHASE_ITEM VALUES (seqIID.nextVal,
		1050, 102, '12-Dec-17', 'Porcelain Lamps', 'Lamps', 13300);

INSERT INTO PURCHASE_ITEM VALUES (seqIID.nextVal,
		1200, 104, '15-Dec-17', 'Gold Rim Design China', 'Tableware', 38500);

INSERT INTO PURCHASE_ITEM VALUES (seqIID.nextVal,
		1200, 104, '16-Dec-17', 'Gold Rim Design Serving Dishes','Tableware', 3200);

INSERT INTO PURCHASE_ITEM VALUES (seqIID.nextVal,
		1050, 102, '07-Apr-18', 'QE Dining Set', 'Furniture', 14300);

INSERT INTO PURCHASE_ITEM VALUES (seqIID.nextVal,
		1100, 103, '18-May-18', 'Misc Linen', 'Linens', 88545);

INSERT INTO PURCHASE_ITEM VALUES (seqIID.nextVal,
		1000, 103, '19-May-18', 'Large Masks', 'Decorations', 22135);

INSERT INTO PURCHASE_ITEM VALUES (seqIID.nextVal,
		1100, 104, '20-May-18', 'Willow Design China', 'Tableware', 147575);

INSERT INTO PURCHASE_ITEM VALUES (seqIID.nextVal,
		1100, 104, '20-May-18', 'Willow Design Serving Dishes', 'Tableware', 12040);

INSERT INTO PURCHASE_ITEM VALUES (seqIID.nextVal,
		1150, 102, '14-Jun-18', 'Woven Goods', 'Decorations', 1200);

INSERT INTO PURCHASE_ITEM VALUES (seqIID.nextVal,
		1150, 101, '16-Jun-18', 'Antique Leather Chairs', 'Furniture', 5375);

INSERT INTO PURCHASE_ITEM VALUES (seqIID.nextVal,
		1100, 104, '15-Jul-18', 'Willow Design Serving Dishes', 'Tableware', 4500);

INSERT INTO PURCHASE_ITEM VALUES (seqIID.nextVal,
		1000, 103, '17-Jul-18', 'Large Bureau', 'Furniture', 9500);

INSERT INTO PURCHASE_ITEM VALUES (seqIID.nextVal,
		1100, 104, '20-Jul-18', 'Brass Lamps', 'Lamps', 1200);

/*****   SHIPMENT Data   ***********************************************************/

INSERT INTO SHIPMENT (ShipmentID, ShipperID, PurchasingAgentID, ShipperInvoiceNumber, Origin, Destination,
		ScheduledDepartureDate, ActualDepartureDate, EstimatedArrivalDate)
		VALUES (seqSHIPMENTID.nextVal, 1, 103, 2017651, 'Manila', 'Los Angeles', '10-Dec-17', '10-Dec-17', '15-Mar-18');

INSERT INTO SHIPMENT VALUES (seqSHIPMENTID.nextVal, 
		1, 104, 2018012, 'Hong Kong', 'Seattle', '10-Jan-18', '12-Jan-18', '20-Mar-18');

INSERT INTO SHIPMENT VALUES (seqSHIPMENTID.nextVal, 
		3, 103, 49100300, 'Manila', 'Los Angeles', '05-May-18', '05-May-18', '17-Jun-18');

INSERT INTO SHIPMENT VALUES (seqSHIPMENTID.nextVal, 
		2, 104, 399400, 'Singapore', 'Portland', '02-Jun-18', '04-Jun-18','17-Jul-18' );

INSERT INTO SHIPMENT VALUES (seqSHIPMENTID.nextVal, 
		3, 103, 84899440, 'Lima', 'Los Angeles', '10-Jul-18', '10-Jul-18', '28-Jul-18');

INSERT INTO SHIPMENT VALUES (seqSHIPMENTID.nextVal, 
		2, 104, 488955,  'Singapore', 'Portland', '05-Aug-18', '09-Aug-18', '11-Sep-18');

/*****   SHIPMENT Item   ***********************************************************/

INSERT INTO SHIPMENT_ITEM VALUES(100, 1, 500, 15000);

INSERT INTO SHIPMENT_ITEM VALUES(100, 2, 505, 15000);

INSERT INTO SHIPMENT_ITEM VALUES(101, 1, 510, 40000);

INSERT INTO SHIPMENT_ITEM VALUES(101, 2, 515, 3500);

INSERT INTO SHIPMENT_ITEM VALUES(102, 1, 520, 15000);

INSERT INTO SHIPMENT_ITEM VALUES(103, 1, 525, 90000);

INSERT INTO SHIPMENT_ITEM VALUES(103, 2, 530, 25000);

INSERT INTO SHIPMENT_ITEM VALUES(103, 3, 535, 150000);

INSERT INTO SHIPMENT_ITEM VALUES(103, 4, 540, 12500);

INSERT INTO SHIPMENT_ITEM VALUES(104, 1, 545, 12500);

INSERT INTO SHIPMENT_ITEM VALUES(104, 2, 550, 5500);

INSERT INTO SHIPMENT_ITEM VALUES(105, 1, 555, 4500);

INSERT INTO SHIPMENT_ITEM VALUES(105, 2, 560, 10000);

INSERT INTO SHIPMENT_ITEM VALUES(105, 3, 565, 1500);

/*****   SHIPMENT_RECEIPT   ***********************************************************/

INSERT INTO SHIPMENT_RECEIPT VALUES(seqRN.NextVal, 100, 500, 105, 
    TO_DATE('17-Mar-18 10:00 AM', 'DD-MON-YY HH:MI AM'), 3, 'Yes', NULL);
INSERT INTO SHIPMENT_RECEIPT VALUES(seqRN.NextVal, 100, 505, 105, 
    TO_DATE('17-Mar-18 10:00 AM', 'DD-MON-YY HH:MI AM'), 50, 'Yes', NULL);
INSERT INTO SHIPMENT_RECEIPT VALUES(seqRN.NextVal, 101, 510, 105, 
    TO_DATE('23-Mar-18 3:30 PM', 'DD-MON-YY HH:MI AM'), 100, 'Yes', NULL);
INSERT INTO SHIPMENT_RECEIPT VALUES(seqRN.NextVal, 101, 515, 105, 
    TO_DATE('23-Mar-18 3:30 PM', 'DD-MON-YY HH:MI AM'), 10, 'Yes', NULL);
INSERT INTO SHIPMENT_RECEIPT VALUES(seqRN.NextVal, 102, 520, 106, 
    TO_DATE('19-Jun-18 10:15 AM', 'DD-MON-YY HH:MI AM'), 1, 'No', 
    'One leg on one chair broken.');
INSERT INTO SHIPMENT_RECEIPT VALUES(seqRN.NextVal, 103, 525, 106, 
    TO_DATE('20-Jul-18 2:20 AM', 'DD-MON-YY HH:MI AM'), 1000, 'Yes', NULL);
INSERT INTO SHIPMENT_RECEIPT VALUES(seqRN.NextVal, 103, 530, 106, 
    TO_DATE('20-Jul-18 2:20 AM', 'DD-MON-YY HH:MI AM'), 100, 'Yes', NULL);
INSERT INTO SHIPMENT_RECEIPT VALUES(seqRN.NextVal, 103, 535, 106, 
    TO_DATE('20-Jul-18 2:20 AM', 'DD-MON-YY HH:MI AM'), 100, 'Yes', NULL);
INSERT INTO SHIPMENT_RECEIPT VALUES(seqRN.NextVal, 103, 540, 106, 
    TO_DATE('20-Jul-18 2:20 AM', 'DD-MON-YY HH:MI AM'), 10, 'Yes', NULL);
INSERT INTO SHIPMENT_RECEIPT VALUES(seqRN.NextVal, 104, 545, 105, 
    TO_DATE('29-Jul-18 9:00 PM', 'DD-MON-YY HH:MI AM'), 100, 'Yes', NULL);
INSERT INTO SHIPMENT_RECEIPT VALUES(seqRN.NextVal, 104, 550, 105, 
    TO_DATE('29-Jul-18 9:00 PM', 'DD-MON-YY HH:MI AM'), 5, 'Yes', NULL);
INSERT INTO SHIPMENT_RECEIPT VALUES(seqRN.NextVal, 105, 555, 106, 
    TO_DATE('14-Sep-18 2:45 PM', 'DD-MON-YY HH:MI AM'), 4, 'Yes', NULL);
INSERT INTO SHIPMENT_RECEIPT VALUES(seqRN.NextVal, 105, 560, 106, 
    TO_DATE('14-Sep-18 2:45 PM', 'DD-MON-YY HH:MI AM'), 1, 'Yes', NULL);
INSERT INTO SHIPMENT_RECEIPT VALUES(seqRN.NextVal, 105, 565, 106, 
    TO_DATE('14-Sep-18 2:45 PM', 'DD-MON-YY HH:MI AM'), 10, 'No', 
    'Base of one lamp scratched');

/********************************************************************************/



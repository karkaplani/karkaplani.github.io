/********************************************************************************/
/*																				*/
/*	Kroenke, Auer, Vandenberg, and Yoder					*/
/*	Database Processing (15th Edition) Chapter 07/10B			*/
/*																				*/
/*	MI Create Tables																*/
/*																				*/
/*	These are the Oracle Express 11gR2 and 12c Release 2 SQL code solutions			*/
/*	   for	Chapter 07/10B 						*/
/********************************************************************************/


CREATE  TABLE EMPLOYEE(
	EmployeeID		Int 			NOT NULL,
	LastName		Char(25) 		NOT NULL,
	FirstName        Char(25) 		NOT NULL,
	Department		Char(35)		NOT NULL,
	Position	Char(35)	NOT NULL,
	Supervisor 		INT 	NULL,
	OfficePhone			Char(12)		NULL,
	OfficeFax				Char(12)		NULL,
	EmailAddress	VarChar(100)	NOT NULL UNIQUE,
	CONSTRAINT 		EMPLOYEE_PK 	PRIMARY KEY(EmployeeID),
	CONSTRAINT	EMPLOYEE_FK_SUPER FOREIGN KEY (Supervisor)
			REFERENCES EMPLOYEE (EmployeeID)
	);

CREATE SEQUENCE seqEID INCREMENT BY 1 START WITH 101;


CREATE TABLE STORE (
	StoreID				Int				NOT NULL,
	StoreName			Char(50)		NOT NULL,
	City				Char(35)		NOT NULL,
	Country				Char(50)		NOT NULL,
	Phone				Char(16)		NOT NULL,
	Fax					Char(16)		NULL,
	EmailAddress		Char(100)		NULL,
	Contact				Char(50)		NOT NULL,
	CONSTRAINT		Store_PK		PRIMARY KEY(StoreID),
	CONSTRAINT		StoreCountry	CHECK
						(Country IN ('Hong Kong', 'India',
						 'Japan', 'Peru','Philippines', 'Singapore',
						 'United States', 'People''s Republic of China'))
	);

CREATE SEQUENCE seqSTOREID INCREMENT BY 50 START WITH 1000;

CREATE TABLE PURCHASE_ITEM (
	PurchaseItemID				Int				NOT NULL,
	StoreID				Int				NOT NULL,
	PurchasingAgentID	Int				NOT NULL,
	PurchaseDate		Date			NOT NULL,
	ItemDescription		VarChar(255)	NOT NULL,
	Category			Char(25)		NULL,
	PriceUSD			Numeric(12,2)	NOT NULL,
	CONSTRAINT		Purchase_Item_PK	PRIMARY KEY (PurchaseItemID),
	CONSTRAINT  	Purch_Item_Store_FK FOREIGN KEY(StoreID)
						REFERENCES STORE(StoreID),
	CONSTRAINT		Ship_Employee_FK 	FOREIGN KEY(PurchasingAgentID)
                       REFERENCES EMPLOYEE(EmployeeID) 	);

CREATE SEQUENCE seqIID INCREMENT BY 5 START WITH 500;

CREATE TABLE SHIPPER (
	ShipperID			Int				NOT NULL,
	ShipperName			Char(50)		NOT NULL,
	Phone				Char(16)		NOT NULL,
	Fax					Char(16)		NULL,
	EmailAddress		Char(100)		NULL,
	Contact				Char(50)		NOT NULL,
	CONSTRAINT		Shipper_PK		PRIMARY KEY(ShipperID)
	);

 
CREATE SEQUENCE seqSHIPPERID INCREMENT BY 1 START WITH 1;

CREATE TABLE SHIPMENT (
	ShipmentID				Int			NOT NULL,
	ShipperID				Int			NOT NULL,
	PurchasingAgentID		Int			NOT NULL,
	ShipperInvoiceNumber	Int			NOT NULL,
	Origin					Char(35)	NOT NULL,
	Destination				Char(35)	NOT NULL,
	ScheduledDepartureDate	Date		NULL,
	ActualDepartureDate		Date		NULL,
	EstimatedArrivalDate	Date		NULL,
	CONSTRAINT		Shipment_PK			PRIMARY KEY (ShipmentID),
	CONSTRAINT  	Ship_Shipper_FK		FOREIGN KEY(ShipperID)
						REFERENCES SHIPPER(ShipperID),
	CONSTRAINT		Shipment_Employee_FK 	FOREIGN KEY(PurchasingAgentID)
                       REFERENCES EMPLOYEE(EmployeeID)	);

CREATE SEQUENCE seqSHIPMENTID INCREMENT BY 1 START WITH 100;

CREATE TABLE SHIPMENT_ITEM (
	ShipmentID				Int				NOT NULL,
	ShipmentItemID			Int				NOT NULL,
	PurchaseItemID					Int				NOT NULL,
	InsuredValue			Numeric(12,2)	DEFAULT 100 NOT NULL,
	CONSTRAINT		ShipmentItem_PK	PRIMARY KEY(ShipmentID, ShipmentItemID),
	CONSTRAINT  	Ship_Item_Ship_FK 		FOREIGN KEY(ShipmentID)
						REFERENCES SHIPMENT(ShipmentID)							     ON DELETE CASCADE,
	CONSTRAINT  	Ship_Item_Purchase_Item_FK FOREIGN KEY(PurchaseItemID)
						REFERENCES PURCHASE_ITEM(PurchaseItemID)							           ON DELETE CASCADE
	);

CREATE TABLE SHIPMENT_RECEIPT (
	ReceiptNumber			Int				NOT NULL,
    ShipmentID				Int				NOT NULL,
	PurchaseItemID					Int				NOT NULL,
    ReceivingAgentID		Int				NOT NULL,
    ReceiptDateTime				Date			NOT NULL,
    ReceiptQuantity			Int				NOT NULL,
    isReceivedUndamaged		Char(3)			NOT NULL,
    DamageNotes				Char(1000)		NULL,
	CONSTRAINT		ShipmentReceipt_PK	    PRIMARY KEY(ReceiptNumber),
	CONSTRAINT		Ship_Receipt_Ship_FK	FOREIGN KEY(ShipmentID)
						REFERENCES SHIPMENT(ShipmentID)							     ON DELETE CASCADE,
	CONSTRAINT		Ship_Receipt_Item_FK	FOREIGN KEY(PurchaseItemID)
						REFERENCES PURCHASE_ITEM(PurchaseItemID)							          ON DELETE CASCADE,
	CONSTRAINT		Ship_Receipt_Emp_FK	FOREIGN KEY(ReceivingAgentID)
							REFERENCES EMPLOYEE(EmployeeID)
	);

CREATE SEQUENCE seqRN INCREMENT BY 1 START WITH 200001;
    

/********************************************************************************/

/*DROP TABLE SHIPMENT_RECEIPT;
DROP TABLE SHIPMENT_ITEM;
DROP TABLE SHIPMENT;
DROP TABLE SHIPPER;
DROP TABLE PURCHASE_ITEM;
DROP TABLE STORE;
DROP TABLE EMPLOYEE;*/

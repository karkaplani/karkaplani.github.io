create or replace NONEDITIONABLE FUNCTION StoreContactAndPhone
-- These are the input parameters
(
varPhone Char,
varContact Char
)
-- This is the variable that will hold the returned value
RETURN Varchar
is varFullContact Varchar(60);
BEGIN
-- SQL statements to concatenate the names in the proper order
varFullContact := (RTRIM(varPhone) || ' '|| RTRIM(varContact));
-- Return the concatenated name
RETURN varFullContact;
END;